/**
 * Object that is used by prompts.js to insert all the prompts available to the form designer.
 * Declared as a separate empty object so as to eliminate many circular dependencies.
 */
define({});