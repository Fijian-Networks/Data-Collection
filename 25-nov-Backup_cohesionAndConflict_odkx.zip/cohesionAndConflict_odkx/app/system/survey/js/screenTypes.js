/**
 * Object that is used by screens.js to insert all the screens available to the form designer.
 * Declared as a separate empty object so as to eliminate many circular dependencies.
 */
define({});
