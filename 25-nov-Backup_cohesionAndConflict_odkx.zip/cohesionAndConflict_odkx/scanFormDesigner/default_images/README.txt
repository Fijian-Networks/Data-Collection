These images are loaded into the four corners of each new page that is added to a Scan document.
