The images in the style directory are used by the imgAreaSelect library to create animated, dashed borders around selected image regions in the image editing tab.

