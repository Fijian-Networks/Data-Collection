This directory contains the views which provide/control field parameters (field display text, field names, field margains). 

Views respond to the actions that the user performs and updates (ex: user sets a field to have a border, the RadioButton
view updates to display the border width option). 
