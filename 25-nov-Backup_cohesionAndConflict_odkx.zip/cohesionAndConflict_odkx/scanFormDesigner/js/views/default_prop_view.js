/*
*	Constructs the default view that is shown in the 
*	field properties sidebar when no field is 
*	currently selected.
*/
ODKScan.DefaultPropView = Ember.View.create({
  templateName: 'default-prop-view'
});