window.odkTableSpecificDefinitions = {
  "_tokens": {
    "first_prompt": {
      "string_token": "first_prompt",
      "text": {
        "default": "Enter an initial rating (1-10) for this survey",
        "hi": "HINDI Enter an initial rating (1-10) for this survey"
      },
      "_row_num": 2
    }
  }
}