/**
 * The file for displaying a detail view.
 */
'use strict';
 
function display() {
    // Perform your modification of the HTML page here and call display() in
    // the body of your .html file.
}

